#include "GameTestRunner.h"

#include "GameTestInstance.h"
#include "GameTestTicker.h"
#include "ConsoleGameTestListener.h"

namespace gametest
{
    
	void GameTestRunner::runTest(std::shared_ptr<GameTestInstance> test, int x, int y, int z, GameTestTicker& ticker) {
		test->startExecution();
		ticker.add(test);
		test->addListener(std::make_shared<ConsoleGameTestListener>());
		test->spawnStructure();
	}

} // namespace gametest

