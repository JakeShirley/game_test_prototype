#pragma once

namespace gametest
{
    class GameTestInstance;

    class IGameTestListener
    {
    public:
        virtual ~IGameTestListener() = default;

        virtual void onTestStructureLoaded(GameTestInstance &test) = 0;
        virtual void onTestPassed(GameTestInstance &test) = 0;
        virtual void onTestFailed(GameTestInstance &test) = 0;
	};
} // namespace gametest