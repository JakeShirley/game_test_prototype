#pragma once

#include <string>

namespace gametest
{
    class GameTestInstance;
    class GameTestTicker;

    class GameTestRunner
    {
    public:
       static void runTest(std::shared_ptr<GameTestInstance> test, int x, int y, int z, GameTestTicker& ticker);
	};
} // namespace gametest

