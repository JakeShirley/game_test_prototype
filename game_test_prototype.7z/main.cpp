
#include <optional>
#include <memory>

#include "GameTestInstance.h"
#include "NativeGameTestFunction.h"
#include "BaseGameTestHelper.h"
#include "ConsoleGameTestListener.h"
#include "GameTestRunner.h"
#include "IGameTestHelperProvider.h"
#include "GameTestTicker.h"

class DebugGameTestHelperProvider : public gametest::IGameTestHelperProvider {
public:
	virtual std::unique_ptr<gametest::BaseGameTestHelper> createGameTestHelper(gametest::GameTestInstance &testInstance) {
		return std::make_unique<gametest::BaseGameTestHelper>(testInstance);
	}
};

int main() {
	std::optional<int> test = 4;

	auto nativeGameTestFn = std::make_shared<gametest::NativeGameTestFunction>("test_batch", "test_fn", "test_structure", 100, 0, true, [](gametest::BaseGameTestHelper& helper) {
		helper.succeedIf([]() {
			return gametest::GameTestError{ gametest::GameTestErrorType::Unknown, "Failed because fuck you that's why" };
		});
	});

	DebugGameTestHelperProvider testHelper;
	gametest::GameTestTicker testTicker;

	auto gameTestInstance = std::make_shared<gametest::GameTestInstance>(*nativeGameTestFn, testHelper);

	gametest::GameTestRunner::runTest(gameTestInstance, 0, 0, 0, testTicker);

	while (!testTicker.empty()) {
		testTicker.tick();
		gametest::GameTestInstance::sLevelTick++;
	}

	return 0;
}